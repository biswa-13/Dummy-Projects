			<div class="side-menu fl">
				
				<h3>Portal Links</h3>
				<ul>
					<li><a href="Profile.php">Profile</a></li>
					<li><a href="academic.php">Academic</a></li>
					<li><a href="mycv.php">Update CV</a></li>
					<!-- <li><a href="#">Settings</a></li> -->
					<li><a href="ChangePassword.php">Change Password</a></li>
				</ul>
				
			</div> <!-- end side-menu -->