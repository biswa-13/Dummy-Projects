
	<!-- HEADER -->
	<div id="header-with-tabs">
		
		<div class="page-full-width cf">
	
			<ul id="tabs" class="fl">
				<li><a href="index.php" class="active-tab dashboard-tab">Dashboard</a></li>
				<li><a href="Chat.php" id="blink1">Chat with utkal placement</a></li>
			</ul> <!-- end tabs -->
			
			<!-- Change this image to your own company's logo -->
			<!-- The logo will automatically be resized to 30px height. -->
			<a href="#" id="company-branding-small" class="fr" ><img src="images/placeholder-profile.jpg" alt="<?php echo $user_data['first_name'];?>" /></a>
			
		</div> <!-- end full-width -->	

	</div> <!-- end header -->
	
	<script type="text/javascript">
	var $_Tawk_API={},$_Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/5569962af81778866e5eb1cb/default';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
	</script>