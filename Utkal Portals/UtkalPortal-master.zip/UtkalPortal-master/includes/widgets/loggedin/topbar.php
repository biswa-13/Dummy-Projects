	<!-- TOP BAR -->
	<div id="top-bar">
		
		<div class="page-full-width cf">

			<ul id="nav" class="fl">
	
				<li class="v-sep"><a href="profile.php" class="round button dark menu-user image-left">Logged in as <strong><?php echo $user_data['first_name']; ?></strong></a></li>
			
				<li><a href="Logout.php" class="round button dark menu-logoff image-left">Log out</a></li>
				
			</ul> <!-- end nav -->

					
		

		</div> <!-- end full-width -->	
	
	</div> <!-- end top-bar -->