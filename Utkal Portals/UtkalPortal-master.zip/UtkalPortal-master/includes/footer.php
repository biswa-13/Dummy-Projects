	<!-- FOOTER -->
	<div id="footer">

		<p>&copy; Copyright 2015 <a href="#">PLACEMENT CELL, UTKAL UNIVERSITY</a>.  All rights reserved. </p>
		<p> <a href="#"> <strong> PLACEMENT PORTAL 2015 </strong> </a> Developed by <a href="#">Students Of Integrated MCA, Utkal University</a></p>
	
	</div> <!-- end footer -->
	
</body>
</html>