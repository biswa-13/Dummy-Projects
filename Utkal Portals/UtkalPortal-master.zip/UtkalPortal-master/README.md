# Utkal_Portal_Project
Hi all this is going to be used as Code Repository and Sub Version Management Tool for our Utkal University Placement Portal Project.
So to maintain a perfect code base  i would like to request all the members to follow some of the rules, Which are as follows

1 - All members should create their GitHib Account to access the project . <br>
2 - All members should Fork , Follow , and set Watch option on to the Main Project. <br>
3 - Instead of directly doing editing into any code all members are requested to copy thee project to their system and work on the project .<br>
4 - After succesfully done the work test it properly in your local systems browser.<br>
5 - And send me a Pull Request.<br>
6 - All web pages should include one one document for describing their functionalities along with the initial owner name of that page, any changes made to any web page will be recorded in the coressponding document page along with the region, date, and owner of the modefication .<br>
<b>NOTE : </b> <i>No member can remove or edit directly to the main Project Repository For Any Changes members/developers has to send  a Pull Request .</i>

<h1><b><i>Developers Details :- </i></b></h1>

<table>
  <thead>
    <td>Sl No</td>
    <td>Name </td>
    <td>Mobile No</td>
    <td>Email Id</td>
    <td>Qualification</td>
    <td>Designation</td>
  </thead>
  <tbody>
    <tr>
      <td>1 .</td>
      <td>Biswa Ranjan Samal</td>
      <td>7205284238</td>
      <td>bichhubiswa@gmail.com</td>
      <td>MCA, M.Tech-CSE(Continuing)</td>
      <td>Software Engeenier</td>
    </tr>
    <tr>
      <td>2 .</td>
      <td>Priyabrata Pati</td>
      <td>9583145558</td>
      <td>priyabrata.pati36@gmail.com</td>
      <td>Integrated MCA(Continuing)</td>
      <td>Student</td>
    </tr>
  <\tbody>
</table>
