          <section class="content-header">
          <h1>
            Welcome aboard to Utkal Placement Portal
          </h1>
          </section>

        <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">

                <p><font size=3>Utkal Placement portal is connecting you with University Placement Cell. A platform that decreases the gap between the Students and Placement cell and Let you more interactive about recruitment process.</font></p>

                <p><font size=3>From keeping you updated on Utkal Placement to answering your queries and helping you explore a world of opportunities.</font></p>

                <p><font size=3>So, go ahead! Explore opportunities. Experience Certainty.</font></p>
              </h3>

              <br><br>
              <!--
              <div class="col-md-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#activity" data-toggle="tab"><b>Activity</b></a></li>
                  <li><a href="#timeline" data-toggle="tab"><b>Timeline</b></a></li>
                </ul>
                <div class="tab-content">
                  <div class="active tab-pane" id="activity">
                    
                    <div class="post">
                      <div class="user-block">
                        <span class='username'>
                          <a href="#">You changed your profile</a>
                          <a href='#' class='pull-right btn-box-tool'><i class='fa fa-times'></i></a>
                        </span>
                        <span class='description'>7:30 PM today</span>
                      </div><
                      <p>
                        Lorem ipsum represents a long-held tradition for designers,
                        typographers and the like. Some people hate it and argue for
                        its demise, but others ignore the hate as they create awesome
                        tools to help create filler text for everyone from bacon lovers
                        to Charlie Sheen fans.
                      </p>
                    </div>
                    
                  </div>
                  <div class="tab-pane" id="timeline">
                    
                    <ul class="timeline timeline-inverse">
                      
                      <li class="time-label">
                        <span class="bg-red">
                          10 Feb. 2014
                        </span>
                      </li>
                      <li>
                        <i class="fa fa-envelope bg-blue"></i>
                        <div class="timeline-item">
                          <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>
                          <h3 class="timeline-header"><a href="#">Placement Cell</a> sent you an email</h3>
                          <div class="timeline-body">
                            Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                            weebly ning heekya handango imeem plugg dopplr jibjab, movity
                            jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                            quora plaxo ideeli hulu weebly balihoo...
                          </div>
                          <div class="timeline-footer">
                            <a class="btn btn-primary btn-xs">Read more</a>
                            <a class="btn btn-danger btn-xs">Delete</a>
                          </div>
                        </div>
                      </li>
                      <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                          <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>
                          <h3 class="timeline-header no-border"><a href="#">Your Friend</a> just registered in the Utkal Placement Portal.</h3>
                        </div>
                      </li>
                 
                      <li>
                        <i class="fa fa-clock-o bg-gray"></i>
                      </li>
                    </ul>
                  </div>
                </div>
              -->
              </div><!-- /.nav-tabs-custom -->
            </div>
            </div>

            </div>

          </div><!-- /.box -->

        </section><!-- /.content -->
