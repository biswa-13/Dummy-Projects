<?php
	session_start();
	error_reporting(0);

	require 'dbconnect.php';
	require 'functions.php';

	
?>